[
    {
        "storeNbr": 3571,
        "BenefitListForDepartments": [
            {
                "departmentID": 3336,
                "footage": 15.0,
                "units": 50.0,
                "sales": 50.0,
                "grossMargin": 50.0,
                "comprehensiveProfit": 50.0
            },
            {
                "departmentID": 3436,
                "footage": 27.0,
                "units": 124.0,
                "sales": 124.0,
                "grossMargin": 124.0,
                "comprehensiveProfit": 124.0
            },
            {
                "departmentID": 3320,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3371,
                "footage": 30.0,
                "units": 83.0,
                "sales": 83.0,
                "grossMargin": 83.0,
                "comprehensiveProfit": 83.0
            },
            {
                "departmentID": 3369,
                "footage": 18.0,
                "units": 75.0,
                "sales": 75.0,
                "grossMargin": 75.0,
                "comprehensiveProfit": 75.0
            },
            {
                "departmentID": 3381,
                "footage": 12.0,
                "units": 15.0,
                "sales": 15.0,
                "grossMargin": 15.0,
                "comprehensiveProfit": 15.0
            },
            {
                "departmentID": 3325,
                "footage": 18.0,
                "units": 14.0,
                "sales": 14.0,
                "grossMargin": 14.0,
                "comprehensiveProfit": 14.0
            },
            {
                "departmentID": 1520,
                "footage": 9.0,
                "units": 504.0,
                "sales": 504.0,
                "grossMargin": 504.0,
                "comprehensiveProfit": 504.0
            },
            {
                "departmentID": 3302,
                "footage": 30.0,
                "units": 113.0,
                "sales": 113.0,
                "grossMargin": 113.0,
                "comprehensiveProfit": 113.0
            },
            {
                "departmentID": 2772,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 3342,
                "footage": 15.0,
                "units": 82.0,
                "sales": 82.0,
                "grossMargin": 82.0,
                "comprehensiveProfit": 82.0
            },
            {
                "departmentID": 2168,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3377,
                "footage": 3.0,
                "units": 9.0,
                "sales": 9.0,
                "grossMargin": 9.0,
                "comprehensiveProfit": 9.0
            },
            {
                "departmentID": 3550,
                "footage": 9.0,
                "units": 16.0,
                "sales": 16.0,
                "grossMargin": 16.0,
                "comprehensiveProfit": 16.0
            },
            {
                "departmentID": 3442,
                "footage": 9.0,
                "units": 17.0,
                "sales": 17.0,
                "grossMargin": 17.0,
                "comprehensiveProfit": 17.0
            },
            {
                "departmentID": 3366,
                "footage": 27.0,
                "units": 69.0,
                "sales": 69.0,
                "grossMargin": 69.0,
                "comprehensiveProfit": 69.0
            },
            {
                "departmentID": 3534,
                "footage": 9.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 3560,
                "footage": 6.0,
                "units": 59.0,
                "sales": 59.0,
                "grossMargin": 59.0,
                "comprehensiveProfit": 59.0
            },
            {
                "departmentID": 3399,
                "footage": 3.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 1315,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3364,
                "footage": 9.0,
                "units": 38.0,
                "sales": 38.0,
                "grossMargin": 38.0,
                "comprehensiveProfit": 38.0
            },
            {
                "departmentID": 3350,
                "footage": 15.0,
                "units": 13.0,
                "sales": 13.0,
                "grossMargin": 13.0,
                "comprehensiveProfit": 13.0
            },
            {
                "departmentID": 3386,
                "footage": 8.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 3335,
                "footage": 9.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 310,
                "footage": 7.0,
                "units": 44.0,
                "sales": 44.0,
                "grossMargin": 44.0,
                "comprehensiveProfit": 44.0
            },
            {
                "departmentID": 3334,
                "footage": 9.0,
                "units": 18.0,
                "sales": 18.0,
                "grossMargin": 18.0,
                "comprehensiveProfit": 18.0
            },
            {
                "departmentID": 3805,
                "footage": 10.0,
                "units": 11.0,
                "sales": 11.0,
                "grossMargin": 11.0,
                "comprehensiveProfit": 11.0
            },
            {
                "departmentID": 1472,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3303,
                "footage": 12.0,
                "units": 20.0,
                "sales": 20.0,
                "grossMargin": 20.0,
                "comprehensiveProfit": 20.0
            },
            {
                "departmentID": 3449,
                "footage": 30.0,
                "units": 61.0,
                "sales": 61.0,
                "grossMargin": 61.0,
                "comprehensiveProfit": 61.0
            },
            {
                "departmentID": 1965,
                "footage": 1.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3536,
                "footage": 18.0,
                "units": 86.0,
                "sales": 86.0,
                "grossMargin": 86.0,
                "comprehensiveProfit": 86.0
            },
            {
                "departmentID": 3376,
                "footage": 21.0,
                "units": 64.0,
                "sales": 64.0,
                "grossMargin": 64.0,
                "comprehensiveProfit": 64.0
            },
            {
                "departmentID": 3307,
                "footage": 27.0,
                "units": 55.0,
                "sales": 55.0,
                "grossMargin": 55.0,
                "comprehensiveProfit": 55.0
            },
            {
                "departmentID": 3345,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3316,
                "footage": 18.0,
                "units": 56.0,
                "sales": 56.0,
                "grossMargin": 56.0,
                "comprehensiveProfit": 56.0
            },
            {
                "departmentID": 5489,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1545,
                "footage": 3.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 3374,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 3437,
                "footage": 9.0,
                "units": 48.0,
                "sales": 48.0,
                "grossMargin": 48.0,
                "comprehensiveProfit": 48.0
            },
            {
                "departmentID": 2941,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 228,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3348,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 234,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9190,
                "footage": 9.0,
                "units": 21.0,
                "sales": 21.0,
                "grossMargin": 21.0,
                "comprehensiveProfit": 21.0
            },
            {
                "departmentID": 3353,
                "footage": 36.0,
                "units": 103.0,
                "sales": 103.0,
                "grossMargin": 103.0,
                "comprehensiveProfit": 103.0
            },
            {
                "departmentID": 3315,
                "footage": 3.0,
                "units": 9.0,
                "sales": 9.0,
                "grossMargin": 9.0,
                "comprehensiveProfit": 9.0
            },
            {
                "departmentID": 3370,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 254,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2175,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3360,
                "footage": 30.0,
                "units": 42.0,
                "sales": 42.0,
                "grossMargin": 42.0,
                "comprehensiveProfit": 42.0
            },
            {
                "departmentID": 247,
                "footage": 12.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 1766,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3327,
                "footage": 6.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 2188,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3326,
                "footage": 15.0,
                "units": 21.0,
                "sales": 21.0,
                "grossMargin": 21.0,
                "comprehensiveProfit": 21.0
            },
            {
                "departmentID": 1446,
                "footage": 3.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 3383,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 3318,
                "footage": 12.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 3346,
                "footage": 3.0,
                "units": 66.0,
                "sales": 66.0,
                "grossMargin": 66.0,
                "comprehensiveProfit": 66.0
            },
            {
                "departmentID": 8675,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3400,
                "footage": 14.0,
                "units": 30.0,
                "sales": 30.0,
                "grossMargin": 30.0,
                "comprehensiveProfit": 30.0
            },
            {
                "departmentID": 3317,
                "footage": 12.0,
                "units": 35.0,
                "sales": 35.0,
                "grossMargin": 35.0,
                "comprehensiveProfit": 35.0
            },
            {
                "departmentID": 3443,
                "footage": 12.0,
                "units": 119.0,
                "sales": 119.0,
                "grossMargin": 119.0,
                "comprehensiveProfit": 119.0
            },
            {
                "departmentID": 3337,
                "footage": 12.0,
                "units": 20.0,
                "sales": 20.0,
                "grossMargin": 20.0,
                "comprehensiveProfit": 20.0
            },
            {
                "departmentID": 3356,
                "footage": 9.0,
                "units": 39.0,
                "sales": 39.0,
                "grossMargin": 39.0,
                "comprehensiveProfit": 39.0
            },
            {
                "departmentID": 3410,
                "footage": 0.0,
                "units": 47.0,
                "sales": 47.0,
                "grossMargin": 47.0,
                "comprehensiveProfit": 47.0
            },
            {
                "departmentID": 2118,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3406,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3329,
                "footage": 15.0,
                "units": 13.0,
                "sales": 13.0,
                "grossMargin": 13.0,
                "comprehensiveProfit": 13.0
            },
            {
                "departmentID": 3408,
                "footage": 16.0,
                "units": 29.0,
                "sales": 29.0,
                "grossMargin": 29.0,
                "comprehensiveProfit": 29.0
            },
            {
                "departmentID": 1402,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3439,
                "footage": 3.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 3390,
                "footage": 9.0,
                "units": 143.0,
                "sales": 143.0,
                "grossMargin": 143.0,
                "comprehensiveProfit": 143.0
            },
            {
                "departmentID": 2169,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3361,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2163,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 3441,
                "footage": 18.0,
                "units": 100.0,
                "sales": 100.0,
                "grossMargin": 100.0,
                "comprehensiveProfit": 100.0
            },
            {
                "departmentID": 2187,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3308,
                "footage": 9.0,
                "units": 22.0,
                "sales": 22.0,
                "grossMargin": 22.0,
                "comprehensiveProfit": 22.0
            },
            {
                "departmentID": 9324,
                "footage": 18.0,
                "units": 342.0,
                "sales": 342.0,
                "grossMargin": 342.0,
                "comprehensiveProfit": 342.0
            },
            {
                "departmentID": 3450,
                "footage": 6.0,
                "units": 13.0,
                "sales": 13.0,
                "grossMargin": 13.0,
                "comprehensiveProfit": 13.0
            },
            {
                "departmentID": 3330,
                "footage": 9.0,
                "units": 55.0,
                "sales": 55.0,
                "grossMargin": 55.0,
                "comprehensiveProfit": 55.0
            },
            {
                "departmentID": 3328,
                "footage": 0.0,
                "units": 17.0,
                "sales": 17.0,
                "grossMargin": 17.0,
                "comprehensiveProfit": 17.0
            },
            {
                "departmentID": 5849,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3300,
                "footage": 12.0,
                "units": 73.0,
                "sales": 73.0,
                "grossMargin": 73.0,
                "comprehensiveProfit": 73.0
            },
            {
                "departmentID": 9894,
                "footage": 12.0,
                "units": 25.0,
                "sales": 25.0,
                "grossMargin": 25.0,
                "comprehensiveProfit": 25.0
            },
            {
                "departmentID": 3304,
                "footage": 3.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 3347,
                "footage": 6.0,
                "units": 40.0,
                "sales": 40.0,
                "grossMargin": 40.0,
                "comprehensiveProfit": 40.0
            },
            {
                "departmentID": 8601,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 5680,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 130,
                "footage": 12.0,
                "units": 52.0,
                "sales": 52.0,
                "grossMargin": 52.0,
                "comprehensiveProfit": 52.0
            },
            {
                "departmentID": 3344,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5891,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 3461,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3401,
                "footage": 9.0,
                "units": 25.0,
                "sales": 25.0,
                "grossMargin": 25.0,
                "comprehensiveProfit": 25.0
            },
            {
                "departmentID": 3312,
                "footage": 9.0,
                "units": 72.0,
                "sales": 72.0,
                "grossMargin": 72.0,
                "comprehensiveProfit": 72.0
            },
            {
                "departmentID": 7888,
                "footage": 8.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 3343,
                "footage": 9.0,
                "units": 71.0,
                "sales": 71.0,
                "grossMargin": 71.0,
                "comprehensiveProfit": 71.0
            },
            {
                "departmentID": 3324,
                "footage": 8.0,
                "units": 116.0,
                "sales": 116.0,
                "grossMargin": 116.0,
                "comprehensiveProfit": 116.0
            },
            {
                "departmentID": 3339,
                "footage": 18.0,
                "units": 88.0,
                "sales": 88.0,
                "grossMargin": 88.0,
                "comprehensiveProfit": 88.0
            },
            {
                "departmentID": 3382,
                "footage": 6.0,
                "units": 22.0,
                "sales": 22.0,
                "grossMargin": 22.0,
                "comprehensiveProfit": 22.0
            },
            {
                "departmentID": 311,
                "footage": 7.0,
                "units": 120.0,
                "sales": 120.0,
                "grossMargin": 120.0,
                "comprehensiveProfit": 120.0
            },
            {
                "departmentID": 2785,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3313,
                "footage": 9.0,
                "units": 31.0,
                "sales": 31.0,
                "grossMargin": 31.0,
                "comprehensiveProfit": 31.0
            },
            {
                "departmentID": 2704,
                "footage": 9.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 5893,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2243,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1002,
                "footage": 9.0,
                "units": 243.0,
                "sales": 243.0,
                "grossMargin": 243.0,
                "comprehensiveProfit": 243.0
            },
            {
                "departmentID": 3351,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5202,
                "footage": 9.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 3427,
                "footage": 6.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 2949,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1343,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1011,
                "footage": 6.0,
                "units": 22.0,
                "sales": 22.0,
                "grossMargin": 22.0,
                "comprehensiveProfit": 22.0
            },
            {
                "departmentID": 3305,
                "footage": 15.0,
                "units": 19.0,
                "sales": 19.0,
                "grossMargin": 19.0,
                "comprehensiveProfit": 19.0
            },
            {
                "departmentID": 2344,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1748,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3332,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2935,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3314,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1470,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1335,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5984,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 3544,
                "footage": 6.0,
                "units": 9.0,
                "sales": 9.0,
                "grossMargin": 9.0,
                "comprehensiveProfit": 9.0
            },
            {
                "departmentID": 1726,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4689,
                "footage": 2.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 3352,
                "footage": 3.0,
                "units": 10.0,
                "sales": 10.0,
                "grossMargin": 10.0,
                "comprehensiveProfit": 10.0
            },
            {
                "departmentID": 3372,
                "footage": 4.0,
                "units": 49.0,
                "sales": 49.0,
                "grossMargin": 49.0,
                "comprehensiveProfit": 49.0
            },
            {
                "departmentID": 3311,
                "footage": 12.0,
                "units": 76.0,
                "sales": 76.0,
                "grossMargin": 76.0,
                "comprehensiveProfit": 76.0
            },
            {
                "departmentID": 1405,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9046,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1359,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2022,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3338,
                "footage": 9.0,
                "units": 10.0,
                "sales": 10.0,
                "grossMargin": 10.0,
                "comprehensiveProfit": 10.0
            },
            {
                "departmentID": 3375,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 5175,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3668,
                "footage": 12.0,
                "units": 17.0,
                "sales": 17.0,
                "grossMargin": 17.0,
                "comprehensiveProfit": 17.0
            },
            {
                "departmentID": 3387,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3586,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1034,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1986,
                "footage": 6.0,
                "units": 89.0,
                "sales": 89.0,
                "grossMargin": 89.0,
                "comprehensiveProfit": 89.0
            },
            {
                "departmentID": 2296,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5945,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3444,
                "footage": 3.0,
                "units": 9.0,
                "sales": 9.0,
                "grossMargin": 9.0,
                "comprehensiveProfit": 9.0
            },
            {
                "departmentID": 5010,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1005,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2006,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1276,
                "footage": 9.0,
                "units": 39.0,
                "sales": 39.0,
                "grossMargin": 39.0,
                "comprehensiveProfit": 39.0
            },
            {
                "departmentID": 3801,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5174,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6290,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1441,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9208,
                "footage": 2.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 9321,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 3349,
                "footage": 6.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 5890,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3663,
                "footage": 3.0,
                "units": 18.0,
                "sales": 18.0,
                "grossMargin": 18.0,
                "comprehensiveProfit": 18.0
            },
            {
                "departmentID": 2900,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3306,
                "footage": 3.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 3398,
                "footage": 10.0,
                "units": 14.0,
                "sales": 14.0,
                "grossMargin": 14.0,
                "comprehensiveProfit": 14.0
            },
            {
                "departmentID": 1960,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5453,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 3363,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1706,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2942,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1425,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2233,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 252,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8705,
                "footage": 1.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1030,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1746,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3385,
                "footage": 6.0,
                "units": 24.0,
                "sales": 24.0,
                "grossMargin": 24.0,
                "comprehensiveProfit": 24.0
            },
            {
                "departmentID": 235,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 253,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3411,
                "footage": 6.0,
                "units": 23.0,
                "sales": 23.0,
                "grossMargin": 23.0,
                "comprehensiveProfit": 23.0
            },
            {
                "departmentID": 3392,
                "footage": 15.0,
                "units": 100.0,
                "sales": 100.0,
                "grossMargin": 100.0,
                "comprehensiveProfit": 100.0
            },
            {
                "departmentID": 1466,
                "footage": 3.0,
                "units": 24.0,
                "sales": 24.0,
                "grossMargin": 24.0,
                "comprehensiveProfit": 24.0
            },
            {
                "departmentID": 3396,
                "footage": 3.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 5203,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3426,
                "footage": 6.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 9670,
                "footage": 6.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 3535,
                "footage": 6.0,
                "units": 26.0,
                "sales": 26.0,
                "grossMargin": 26.0,
                "comprehensiveProfit": 26.0
            },
            {
                "departmentID": 1721,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6211,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1399,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3368,
                "footage": 15.0,
                "units": 23.0,
                "sales": 23.0,
                "grossMargin": 23.0,
                "comprehensiveProfit": 23.0
            },
            {
                "departmentID": 1409,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8402,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3422,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2944,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2909,
                "footage": 12.0,
                "units": 51.0,
                "sales": 51.0,
                "grossMargin": 51.0,
                "comprehensiveProfit": 51.0
            },
            {
                "departmentID": 2199,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3731,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5012,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1484,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2783,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 862,
                "footage": 1.0,
                "units": 12.0,
                "sales": 12.0,
                "grossMargin": 12.0,
                "comprehensiveProfit": 12.0
            },
            {
                "departmentID": 105,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6051,
                "footage": 12.0,
                "units": 13.0,
                "sales": 13.0,
                "grossMargin": 13.0,
                "comprehensiveProfit": 13.0
            },
            {
                "departmentID": 1492,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1698,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1985,
                "footage": 12.0,
                "units": 25.0,
                "sales": 25.0,
                "grossMargin": 25.0,
                "comprehensiveProfit": 25.0
            },
            {
                "departmentID": 2147,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 238,
                "footage": 2.0,
                "units": 23.0,
                "sales": 23.0,
                "grossMargin": 23.0,
                "comprehensiveProfit": 23.0
            },
            {
                "departmentID": 1357,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5578,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2836,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3354,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3319,
                "footage": 3.0,
                "units": 22.0,
                "sales": 22.0,
                "grossMargin": 22.0,
                "comprehensiveProfit": 22.0
            },
            {
                "departmentID": 3833,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1416,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1187,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2020,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2124,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3333,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 3384,
                "footage": 3.0,
                "units": 16.0,
                "sales": 16.0,
                "grossMargin": 16.0,
                "comprehensiveProfit": 16.0
            },
            {
                "departmentID": 1430,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4926,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2399,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 6054,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2487,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5318,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1382,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9942,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5006,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5376,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 233,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5490,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5207,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3355,
                "footage": 12.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1428,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2981,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5204,
                "footage": 6.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 1356,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2094,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 255,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 237,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1045,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1741,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1745,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3358,
                "footage": 3.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 9893,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1460,
                "footage": 2.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 3405,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2943,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5901,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9944,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3388,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2001,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5322,
                "footage": 3.0,
                "units": 11.0,
                "sales": 11.0,
                "grossMargin": 11.0,
                "comprehensiveProfit": 11.0
            },
            {
                "departmentID": 9607,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 2016,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3359,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 3402,
                "footage": 2.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 2968,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1163,
                "footage": 1.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 2970,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2000,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1162,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 9209,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2987,
                "footage": 3.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3301,
                "footage": 3.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 1188,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1400,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3389,
                "footage": 12.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 3310,
                "footage": 3.0,
                "units": 15.0,
                "sales": 15.0,
                "grossMargin": 15.0,
                "comprehensiveProfit": 15.0
            },
            {
                "departmentID": 1191,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9217,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2114,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1012,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9196,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1731,
                "footage": 3.0,
                "units": 11.0,
                "sales": 11.0,
                "grossMargin": 11.0,
                "comprehensiveProfit": 11.0
            },
            {
                "departmentID": 2773,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5956,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5978,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1833,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3362,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9637,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6039,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1713,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2173,
                "footage": 3.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 5963,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5356,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2319,
                "footage": 1.0,
                "units": 41.0,
                "sales": 41.0,
                "grossMargin": 41.0,
                "comprehensiveProfit": 41.0
            },
            {
                "departmentID": 2165,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6008,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3391,
                "footage": 2.0,
                "units": 11.0,
                "sales": 11.0,
                "grossMargin": 11.0,
                "comprehensiveProfit": 11.0
            },
            {
                "departmentID": 2189,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2346,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2434,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5957,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2771,
                "footage": 18.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 8123,
                "footage": 2.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 5280,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1192,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2337,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1044,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2170,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1330,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3434,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3365,
                "footage": 18.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 113,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3321,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1324,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3407,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1451,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1710,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3809,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2971,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5855,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2342,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9205,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9899,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2926,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 246,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5828,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2128,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2176,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2123,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5473,
                "footage": 2.0,
                "units": 51.0,
                "sales": 51.0,
                "grossMargin": 51.0,
                "comprehensiveProfit": 51.0
            },
            {
                "departmentID": 1443,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2975,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6333,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3309,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 2371,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1956,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3933,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2378,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1701,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2092,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5751,
                "footage": 2.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 1481,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5487,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1725,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3367,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1448,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5305,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1456,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5303,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1537,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5090,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1862,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 251,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9162,
                "footage": 4.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1707,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1750,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5041,
                "footage": 5.0,
                "units": 24.0,
                "sales": 24.0,
                "grossMargin": 24.0,
                "comprehensiveProfit": 24.0
            },
            {
                "departmentID": 1353,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1277,
                "footage": 9.0,
                "units": 55.0,
                "sales": 55.0,
                "grossMargin": 55.0,
                "comprehensiveProfit": 55.0
            },
            {
                "departmentID": 1730,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1386,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5579,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2398,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5888,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2396,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1309,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5007,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1457,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2009,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 114,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5048,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5209,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2186,
                "footage": 3.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 2341,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1333,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1033,
                "footage": 3.0,
                "units": 9.0,
                "sales": 9.0,
                "grossMargin": 9.0,
                "comprehensiveProfit": 9.0
            },
            {
                "departmentID": 3404,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5789,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3413,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1774,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9891,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2014,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1496,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2936,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5488,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2907,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1410,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1723,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2144,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5754,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 2194,
                "footage": 2.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1189,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2178,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1968,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1978,
                "footage": 1.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2097,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5887,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1438,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 9110,
                "footage": 3.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 1365,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3667,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2017,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1264,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6066,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1389,
                "footage": 3.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 2928,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3420,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5342,
                "footage": 2.0,
                "units": 11.0,
                "sales": 11.0,
                "grossMargin": 11.0,
                "comprehensiveProfit": 11.0
            },
            {
                "departmentID": 3445,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1013,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5720,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 2343,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 2098,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9329,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5842,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6045,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2336,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5935,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1474,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5534,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1708,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1196,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1392,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5974,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1267,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2150,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5458,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2355,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2983,
                "footage": 9.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1944,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9619,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 5906,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2160,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1350,
                "footage": 2.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1306,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1499,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1347,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1331,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1422,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2397,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5948,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5972,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1734,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2320,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2854,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8989,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2784,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1061,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9938,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1788,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8555,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1256,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5989,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1787,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2177,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2164,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2195,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1459,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1717,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2354,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 131,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9494,
                "footage": 4.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9201,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1352,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1756,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4958,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1338,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1424,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5880,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1304,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6206,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1388,
                "footage": 9.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1783,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1793,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1485,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8552,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1325,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2775,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1255,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1195,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5889,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5627,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1772,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1038,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1505,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2171,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6043,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2339,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1384,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5049,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1266,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3433,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1307,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1329,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1263,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1495,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5316,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1497,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2153,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5253,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5722,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5182,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2117,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5577,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1321,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1494,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5656,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1493,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1432,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2382,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6004,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1265,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1742,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1368,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1801,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1199,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1387,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1789,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3429,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5979,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1758,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9198,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1954,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2179,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1378,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 1454,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1367,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1755,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2328,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1427,
                "footage": 2.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 2138,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5341,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1744,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2481,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 146,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1354,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6059,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1420,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1417,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1958,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5841,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3099,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2984,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1062,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5883,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1476,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1463,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5217,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6402,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5934,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1453,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5829,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4973,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3435,
                "footage": 2.0,
                "units": 7.0,
                "sales": 7.0,
                "grossMargin": 7.0,
                "comprehensiveProfit": 7.0
            },
            {
                "departmentID": 1314,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3421,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1185,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2167,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5037,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5557,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1366,
                "footage": 9.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 9310,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4983,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4874,
                "footage": 2.0,
                "units": 10.0,
                "sales": 10.0,
                "grossMargin": 10.0,
                "comprehensiveProfit": 10.0
            },
            {
                "departmentID": 1035,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1909,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1784,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1419,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1437,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5021,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9211,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1313,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6042,
                "footage": 3.0,
                "units": 6.0,
                "sales": 6.0,
                "grossMargin": 6.0,
                "comprehensiveProfit": 6.0
            },
            {
                "departmentID": 5871,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2115,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2125,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2880,
                "footage": 5.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 2482,
                "footage": 2.0,
                "units": 13.0,
                "sales": 13.0,
                "grossMargin": 13.0,
                "comprehensiveProfit": 13.0
            },
            {
                "departmentID": 1341,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5233,
                "footage": 3.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 3513,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5861,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2183,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5936,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5753,
                "footage": 2.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 1408,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5543,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1396,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2904,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1269,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 3583,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5866,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2795,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5970,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2158,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2837,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6044,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3532,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5255,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1959,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1041,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2154,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1498,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1358,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3540,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1974,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1215,
                "footage": 1.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1003,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1426,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1712,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1477,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1390,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6102,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9218,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1186,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1486,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1747,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1759,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2159,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5876,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1345,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1790,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5872,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1447,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2095,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5040,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1363,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1491,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1355,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1439,
                "footage": 2.0,
                "units": 8.0,
                "sales": 8.0,
                "grossMargin": 8.0,
                "comprehensiveProfit": 8.0
            },
            {
                "departmentID": 6153,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1794,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2325,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2433,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2940,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2357,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1724,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2182,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2369,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2891,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5877,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2340,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2872,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1323,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6101,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5912,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1938,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5905,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5862,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1699,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9214,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5952,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2166,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9297,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3498,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1431,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2096,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1433,
                "footage": 3.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1344,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1385,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1776,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1743,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5843,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1442,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 241,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6007,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6037,
                "footage": 3.0,
                "units": 28.0,
                "sales": 28.0,
                "grossMargin": 28.0,
                "comprehensiveProfit": 28.0
            },
            {
                "departmentID": 2898,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1465,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1317,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1037,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5833,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9953,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2162,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1429,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2873,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2353,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1436,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2789,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1749,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2890,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1040,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1818,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1727,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2366,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1395,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1778,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1349,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1775,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5435,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4875,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1413,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1326,
                "footage": 2.0,
                "units": 4.0,
                "sales": 4.0,
                "grossMargin": 4.0,
                "comprehensiveProfit": 4.0
            },
            {
                "departmentID": 6100,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1464,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1391,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1732,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1393,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5794,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2335,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2197,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 2161,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5962,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1733,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2832,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9890,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 132,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2368,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2348,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5950,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1957,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2099,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1777,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1709,
                "footage": 3.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1702,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5898,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1342,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1859,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9948,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2781,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1462,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5998,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2349,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2181,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5864,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5179,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2367,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1767,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1197,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2151,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1039,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1440,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5457,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5882,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3554,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1418,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5961,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2777,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2198,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5951,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3510,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2184,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5396,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1863,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6009,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1469,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2799,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 6036,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1955,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5881,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5226,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9038,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2862,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5966,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2190,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6093,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5625,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5229,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2347,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3097,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1704,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1381,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9616,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1434,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 7287,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5865,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5926,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1340,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5721,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1043,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5101,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2365,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5987,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1318,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1475,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2193,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1714,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5827,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1722,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2885,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9963,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1364,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1320,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5958,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2172,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1261,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1946,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1467,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1757,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5043,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3605,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1824,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1979,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1337,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5798,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1067,
                "footage": 3.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1346,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1703,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1461,
                "footage": 2.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5454,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 232,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5027,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2318,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1468,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1735,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1781,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3508,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1257,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1258,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1792,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 244,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5760,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5825,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5927,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3098,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5804,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1483,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1791,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1705,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5933,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1383,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5870,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2351,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1455,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5913,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2894,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2383,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2356,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2489,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5178,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5867,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5684,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8320,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2851,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2137,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5983,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6058,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5949,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2867,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2155,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5802,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1473,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9212,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5042,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1782,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 242,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9298,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1253,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2359,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1351,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3548,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5971,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1194,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2019,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1042,
                "footage": 2.0,
                "units": 2.0,
                "sales": 2.0,
                "grossMargin": 2.0,
                "comprehensiveProfit": 2.0
            },
            {
                "departmentID": 1336,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5539,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1449,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5904,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9552,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2196,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5180,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1779,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2334,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1411,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1471,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6040,
                "footage": 3.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 1310,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1482,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1319,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1190,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3460,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2300,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6103,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5941,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2362,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1397,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 2011,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1728,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5538,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2439,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2338,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1780,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1458,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2185,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1252,
                "footage": 2.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1716,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2379,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 7084,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1480,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1027,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2321,
                "footage": 3.0,
                "units": 17.0,
                "sales": 17.0,
                "grossMargin": 17.0,
                "comprehensiveProfit": 17.0
            },
            {
                "departmentID": 1339,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1479,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2884,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2352,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5635,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5994,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5853,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5844,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1305,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5981,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5031,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2488,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1489,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 8349,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1421,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2856,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1308,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1412,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1751,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1445,
                "footage": 2.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 1720,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2380,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1031,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5649,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4324,
                "footage": 1.0,
                "units": 18.0,
                "sales": 18.0,
                "grossMargin": 18.0,
                "comprehensiveProfit": 18.0
            },
            {
                "departmentID": 1452,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1450,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1348,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 932,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5777,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1259,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5885,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1529,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5929,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5884,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2332,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1414,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2360,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1379,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1198,
                "footage": 2.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9614,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6154,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9225,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2329,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1715,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6038,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5779,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 245,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2387,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6003,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5910,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1262,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1478,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2180,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6094,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2273,
                "footage": 3.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1697,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5985,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5967,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2865,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2119,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5778,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2384,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 7873,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2358,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5943,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2364,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2485,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1254,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5780,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6065,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5977,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1444,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5960,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2361,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 134,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5964,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3802,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5965,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6105,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5177,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1991,
                "footage": 2.0,
                "units": 5.0,
                "sales": 5.0,
                "grossMargin": 5.0,
                "comprehensiveProfit": 5.0
            },
            {
                "departmentID": 4969,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5868,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5947,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 924,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5988,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6200,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5854,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1036,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5980,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6033,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2324,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3872,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6026,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2868,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5946,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2385,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2246,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2490,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9946,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6129,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5422,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5032,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1996,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2999,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4917,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9008,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 301,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5790,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4979,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5609,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2002,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1804,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5955,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1711,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5785,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5176,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2131,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9510,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9116,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6152,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1760,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5572,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6603,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5975,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2350,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1828,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5803,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5770,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5976,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5157,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 9978,
                "footage": 3.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5792,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6095,
                "footage": 3.0,
                "units": 3.0,
                "sales": 3.0,
                "grossMargin": 3.0,
                "comprehensiveProfit": 3.0
            },
            {
                "departmentID": 5846,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5214,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2331,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3669,
                "footage": 1.0,
                "units": 1.0,
                "sales": 1.0,
                "grossMargin": 1.0,
                "comprehensiveProfit": 1.0
            },
            {
                "departmentID": 5420,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6006,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2887,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2855,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5823,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 4981,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5026,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2121,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5004,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2363,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5408,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5857,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3514,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5834,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3511,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5817,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2859,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5401,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2323,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2860,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5816,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5639,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5848,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5818,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5791,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5856,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5016,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6017,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1997,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6010,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5482,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5875,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5053,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5907,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6098,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5894,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5761,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5786,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5820,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5576,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5982,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5788,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5822,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2869,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5402,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5784,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5709,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1024,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5973,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5796,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2174,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5879,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5675,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 3541,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2886,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5858,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5824,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5860,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2866,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5839,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6056,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5836,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5826,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2127,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5942,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 1875,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 865,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5793,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5838,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 6096,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5819,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2483,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 2021,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            },
            {
                "departmentID": 5847,
                "footage": 0.0,
                "units": 0.0,
                "sales": 0.0,
                "grossMargin": 0.0,
                "comprehensiveProfit": 0.0
            }
        ]
    }
]