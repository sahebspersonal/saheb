import React from 'react';
import PropTypes from 'prop-types';
import { ButtonGroup, Dropdown, DropdownButton } from 'react-bootstrap';

const DropDownMenuList = (props) => {
  const { dropdownBtn, dropdownList } = props;
  return (
    <DropdownButton as={ButtonGroup} {...dropdownBtn}>
      {dropdownList.map((list) => {
        if (list.type === 'item') {
          return (
            <Dropdown.Item key={list.key} id="dropdown-list-item">
              {list.label}
            </Dropdown.Item>
          );
        } else if (list.type === 'divider') {
          return <Dropdown.Divider key={list.key} />;
        }
        return null;
      })}
    </DropdownButton>
  );
};

DropDownMenuList.propTypes = {
  dropdownBtn: PropTypes.any,
  dropdownList: PropTypes.arrayOf(
    PropTypes.shape({
      key: PropTypes.string,
      type: PropTypes.string,
      label: PropTypes.string
    })
  )
};

export default DropDownMenuList;
