import {
  cleanup,
  fireEvent,
  render,
  waitFor
} from '@testing-library/react';
import useAuthLogin from '../../hooks/useAuthLogin';

describe('useAuthLogin', () => {
  const successSpy = jest.fn();
  const failSpy = jest.fn();
  window.open = jest.fn(() => {});
  const AUTH_URL = 'http://foo.test/authorize';
  const REDIRECT_URL = 'http://foo.test/auth/OAuth2';
  const clientId = 'foo';

  const config = {
    clientId,
    responseType: 'code',
    authorizeUri: AUTH_URL,
    redirectUri: REDIRECT_URL,
    onSuccess: successSpy,
    onFailure: failSpy
  };

  beforeEach(() => {
    cleanup();
  });

  it('should able to render hooks', () => {
    const app = render(useAuthLogin(config));
    expect(app).toBeTruthy();
  });

  it('should able to render with custom buttonText', () => {
    const app = render(useAuthLogin({ ...config, buttonText: 'Auth Login' }));
    expect(app.getByText('Auth Login')).toBeTruthy();
  });

  it('should able to render with custom class name', () => {
    const app = render(
      useAuthLogin({ ...config, buttonText: 'Auth Login', className: 'auth__btn--login' })
    );
    const { container } = app;
    expect(app.getByText('Auth Login')).toBeTruthy();
    expect(container.getElementsByClassName('auth__btn--login').length).toBe(1);
  });

  it('should able to open OAuth Dialog', () => {
    const app = render(
      useAuthLogin({
        ...config,
        buttonText: 'Auth Login'
      })
    );
    const loginBtn = app.getByText('Auth Login');
    fireEvent.click(loginBtn);
    const query = `client_id=${clientId}&redirect_url=${REDIRECT_URL}&response_type=code`;
    waitFor(() => {
      expect(window.open).toBeCalledTimes(1);
      expect(window.open).toHaveBeenCalledWith(`${AUTH_URL}?${query}`);
    });
  });
});
