import axios from "axios";

export default function doPostRequest(url,body){
        return axios.post(url, body)
          .then(res => {
            return res.data;
          }).catch((err)=>{
        console.log('fffyuuytutuititi')
        console.log(err)
        return []
    })
}

