import React from 'react';
import PropTypes from 'prop-types';
import './card.scss';

const Card = ({ cardContent, cardStyles }) => {
  return (
    <div className="card-container" style={cardStyles}>
      <div className="contain">{cardContent()}</div>
    </div>
  );
};

Card.propTypes = {
  cardContent: PropTypes.func,
  cardStyles: PropTypes.any
};

export default Card;
