import React from 'react';
import { cleanup, render } from '@testing-library/react';
import Header from '../../core/header/header';

describe('Header', () => {
  const navList = [
    { label: 'Home', href: '#action1' },
    { label: 'Login', href: '#action2' }
  ];
  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(
      <Header headerTitle={'Header'} headerLink="#header" navList={navList} />
    );
    expect(app).toBeTruthy();
  });
});
