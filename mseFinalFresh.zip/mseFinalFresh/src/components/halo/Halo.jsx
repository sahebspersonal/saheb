import Box from '@mui/material/Box';
import Autocomplete from "@mui/material/Autocomplete";
import TextField from '@mui/material/TextField';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import React, { useState, useEffect } from "react";
import "./halo.scss";
import Chart from "react-apexcharts";
import axios from 'axios';

export const Halo = () => {
    const [store, setStore] = useState('');
    const [department1, setDepartment1] = useState('');
    const [department2, setDepartment2] = useState('');
    const [department3, setDepartment3] = useState('');
    const [department4, setDepartment4] = useState('');
    const [checked, setChecked] = useState(false)
    const [plot, setPlot] = useState(false)
    const [plot2, setPlot2] = useState(false)
    const [plot3, setPlot3] = useState(false)
    const [plot4, setPlot4] = useState(false)
    const [plotData1, setPlotData1] = useState('')
    const [plotData2, setPlotData2] = useState('')
    const [plotData3, setPlotData3] = useState('')
    const [plotData4, setPlotData4] = useState('')
    const [graphData, setGraphData] = useState([])
    const [graphData1, setGraphData1] = useState({});
    const [graphData2, setGraphData2] = useState({});
    const [graphData3, setGraphData3] = useState({});
    const [graphData4, setGraphData4] = useState({});
    const [inputss, setInputss] = useState({
        footage1: 0,
        footage2: 0,
        footage3: 0,
        footage4: 0,
        footage5: 0
    });

    const handleInput = function (e) {
        setInputss({
            ...inputss,
            [e.target.name]: e.target.value
        });
    };
    // const [showkpi, setShowkpi] = useState(false)
    // const clearDept = () => {
    //     setPlotData1();
    //     setPlotData2();
    //     setPlotData3();
    //     setPlotData4();
    // }

    const handleCheck = (event) => {
        setChecked(event.currentTarget.checked);
    };

    useEffect(() => {
        const sdata = {
            benefitModelID: 1,
            storeNbr: "All",
            departmentList: ["All"],
            benefitBlend: ["25", "25", "25", "25"]
        }
        const url = 'https://ds-aks-pf.walgreens.com/mse/benefit-modeler/api/currentBenefits'
        axios.post(url, sdata)
            .then(res => {
                const benefits = res.data;
                setGraphData(benefits);
            })
    }, [])
    const ser = graphData.map((item) => {
        return item.storeNbr
    });

    const ndata = [];
    if (store) {
        const vall = graphData.find(vv => vv.storeNbr === store);
        ndata.push(vall);
    }
    const serz = ndata.map((item) => {
        return item.BenefitListForDepartments
    });
    const mergexx3 = serz.flat(1)

    const ser1 = mergexx3.map((item) => {
        return item.departmentID
    });

    const inputDataArr = []
    for (let input in inputss) {
        inputDataArr.push(inputss[input]);
    }

    function apiCall (index, plotNumber) {
        const sdata = {
            benefitModelID: 1,
            storeNbr: store,
            departmentListAndSizes: [
                {
                    departmentID: index,
                    footage: inputDataArr
                }
            ],
            useHalo: false
        }

        const url = 'https://ds-aks-pf.walgreens.com/mse/benefit-modeler/api/modeledBenefits'
        axios.post(url, sdata)
            .then(res => {
                const benefits = res.data;
                //setGraphData(benefits);
                //return benefits
                if (plotNumber === "plot1") {
                    //setGraphData1(benefits)
                    setPlot(true)
                    setPlotData1(index)
                    doOperationBeforeGraph(benefits, plotNumber, index)
                } else if (plotNumber === "plot2") {
                    //setGraphData2(benefits)
                    setPlot2(true)
                    setPlotData2(index)
                    doOperationBeforeGraph(benefits, plotNumber, index)
                } else if (plotNumber === "plot3") {
                    //setGraphData3(benefits)
                    setPlot3(true)
                    setPlotData3(index)
                    doOperationBeforeGraph(benefits, plotNumber, index)
                } else if (plotNumber === "plot4") {
                    //setGraphData4(benefits)
                    setPlot4(true)
                    setPlotData4(index)
                    doOperationBeforeGraph(benefits, plotNumber, index)
                }
            })
    }

    function doOperationBeforeGraph (apiGraphData, mapNo, plotz) {
        const graphDataArrApi = apiGraphData !== null && apiGraphData.departmentListAndSizes !== null ? apiGraphData.departmentListAndSizes : [];
        drawMap(graphDataArrApi, mapNo, plotz)
    }

    let newval1 = []; let newval2 = []; let newval3 = []; let newval4 = [];

    function drawMap (mapData, mapNo, plotz) {
        const plotdata11 = mapData.length > 0
        ? mapData.find((item) => {
            return item.departmentID === plotz
        })
        : [];

        if (typeof (plotdata11) !== 'undefined' && plotdata11 != null) {
            const plotdatas11 = plotdata11.benefitsForSizes
            const tr1 = plotdatas11.reduce((r, o) => {
                Object.entries(o).forEach(([k, v]) => {
                    r[k] = r[k] || []
                    if (!r[k].includes(v)) r[k].push(v)
                });
                return r;
            },
                Object.create(null));

            const obj = JSON.parse(JSON.stringify(tr1)); const sers = []; sers.push(obj);
            if (sers.length > 0) {
                for (const [key, value] of Object.entries(sers[0])) {
                    sers.push({

                        name: key.charAt(0).toUpperCase() + key.slice(1),
                        data: value
                    })
                }
            }
            if (mapNo === "plot1") {
                newval1 = sers.slice(1);
                setGraphData1(newval1)
            } else if (mapNo === "plot2") {
                newval2 = sers.slice(1);
                setGraphData2(newval2)
            } else if (mapNo === "plot3") {
                newval3 = sers.slice(1);
                setGraphData3(newval3)
            } else if (mapNo === "plot4") {
                newval4 = sers.slice(1);
                setGraphData4(newval4)
            }
        }
    }

    const state = {
        series: graphData1,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData1}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3', '4', '5'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state2 = {
        series: graphData2,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData2}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3', '4', '5'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state3 = {
        series: graphData3,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData3}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3', '4', '5'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state4 = {
        series: graphData4,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData4}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3', '4', '5'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    return (
        <div className="container">
            <div className="wrapper">

                <FormGroup className="fgs">
                    <FormControlLabel control={<Checkbox checked={checked} onChange={handleCheck} />} label="Halo Effect" />

                </FormGroup>

                {checked && (
                    <div className="wrappers">
                        <Autocomplete
                            disablePortal
                            className="fgm"
                            id="combo-box-demo"
                            options={ser}
                            value={store}
                            onChange={(_event, newTeam) => {
                                setStore(newTeam);
                            }}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Store" />}
                        />

                        <Box
                            className="fqg"
                            component="form"
                            sx={{ minWidth: 120 }}
                            noValidate
                            autoComplete="off"
                        >
                            <TextField onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} onChange={handleInput} name="footage1" value={inputss.footage1} id="outlined-basic" label="Footage 1" variant="outlined" />
                        </Box>

                        <Box
                            className="fqg"
                            component="form"
                            sx={{ minWidth: 120 }}
                            noValidate
                            autoComplete="off"
                        >
                            <TextField onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} onChange={handleInput} name="footage2" value={inputss.footage2} id="outlined-basic" label="Footage 2" variant="outlined" />
                        </Box>

                        <Box
                            className="fqg"
                            component="form"
                            sx={{ minWidth: 120 }}
                            noValidate
                            autoComplete="off"
                        >
                            <TextField onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} onChange={handleInput} name="footage3" value={inputss.footage3} id="outlined-basic" label="Footage 3" variant="outlined" />
                        </Box>

                        <Box
                            className="fqg"
                            component="form"
                            sx={{ minWidth: 120 }}
                            noValidate
                            autoComplete="off"
                        >
                            <TextField onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} onChange={handleInput} name="footage4" value={inputss.footage4} id="outlined-basic" label="Footage 4" variant="outlined" />
                        </Box>

                        <Box
                            className="fqg"
                            component="form"
                            sx={{ minWidth: 120 }}
                            noValidate
                            autoComplete="off"
                        >
                            <TextField onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} onChange={handleInput} name="footage5" value={inputss.footage5} id="outlined-basic" label="Footage 5" variant="outlined" />
                        </Box>

                    </div>
                )}
            </div>
            <div className="halo">

                {checked && (

                    <div className="dropdown">
                        <Autocomplete
                            disablePortal
                            className="dd"
                            id="combo-box-demo"
                            options={ser1}
                            value={department1}
                            onChange={(_event, newTeam) => {
                                setDepartment1(newTeam);
                                if (newTeam === '0') {
                                    setPlot(false)
                                } else {
                                    apiCall(newTeam, 'plot1')
                                    //setPlot(true)
                                    //setPlotData1(newTeam)
                                }
                            }}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Department" />}
                        />

                        <Autocomplete
                            disablePortal
                            className="dd"
                            id="combo-box-demo"
                            options={ser1}
                            value={department2}
                            onChange={(_event, newTeam) => {
                                setDepartment2(newTeam);
                                if (newTeam === '0') {
                                    setPlot2(false)
                                } else {
                                    apiCall(newTeam, 'plot2')
                                    // setPlot2(true)
                                    // setPlotData2(newTeam)
                                }
                            }}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Department" />}
                        />

                        <Autocomplete
                            disablePortal
                            className="dd"
                            id="combo-box-demo"
                            options={ser1}
                            value={department3}
                            onChange={(_event, newTeam) => {
                                setDepartment3(newTeam);
                                if (newTeam === '0') {
                                    setPlot2(false)
                                } else {
                                    apiCall(newTeam, 'plot3')
                                    // setPlot3(true)
                                    // setPlotData3(newTeam)
                                }
                            }}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Department" />}
                        />

                        <Autocomplete
                            disablePortal
                            className="dd"
                            id="combo-box-demo"
                            options={ser1}
                            value={department4}
                            onChange={(_event, newTeam) => {
                                setDepartment4(newTeam);
                                if (newTeam === '0') {
                                    setPlot4(false)
                                } else {
                                    apiCall(newTeam, 'plot4')
                                    // setPlot4(true)
                                    // setPlotData4(newTeam)
                                }
                            }}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Department" />}
                        />

                    </div>
                )}

            </div>

            <div className="containers">
                <div>
                    {
                        graphData1?.length > 0
                            ? (
                                <div>
                                    {
                                        plot && (
                                            <div id="chart">
                                                <Chart
                                                    options={state.options}
                                                    series={state.series}
                                                    type="line"
                                                    width="450"
                                                />
                                            </div>
                                        )

                                    }
                                </div>
                            )
                            : (
                                <p className='nodata' />
                            )

                    }
                </div>
                <div>
                    {
                        graphData2?.length > 0
                            ? (
                                <div>
                                    {
                                        plot2 && (
                                            <div id="chart">
                                                <Chart
                                                    options={state2.options}
                                                    series={state2.series}
                                                    type="line"
                                                    width="450"
                                                />
                                            </div>
                                        )

                                    }
                                </div>
                            )
                            : (
                                <p className='nodata' />
                            )

                    }
                </div>
                <div>
                    {
                        graphData3?.length > 0
                            ? (
                                <div>
                                    {
                                        plot3 && (
                                            <div id="chart">
                                                <Chart
                                                    options={state3.options}
                                                    series={state3.series}
                                                    type="line"
                                                    width="450"
                                                />
                                            </div>
                                        )

                                    }
                                </div>
                            )
                            : (
                                <p className='nodata' />
                            )

                    }
                </div>
                <div>
                    {
                        graphData4?.length > 0
                            ? (
                                <div>
                                    {
                                        plot4 && (
                                            <div id="chart">
                                                <Chart
                                                    options={state4.options}
                                                    series={state4.series}
                                                    type="line"
                                                    width="450"
                                                />
                                            </div>
                                        )

                                    }
                                </div>
                            )
                            : (
                                <p className='nodata' />
                            )

                    }
                </div>

            </div>
        </div>
    )
}
