export const mdata = {
    storeNbr: 3571,
    departmentListAndSizes: [
        {

            departmentID: 3410,
            benefitsForSizes: [
                {
                    footage: 10.0,
                    units: 84.55477350828399,
                    sales: 84.55477350828399,
                    grossMargin: 84.55477350828399,
                    comprehensiveProfit: 84.55477350828399
                },

                {
                    footage: 15.0,
                    units: 105.57315281147139,
                    sales: 105.57315281147139,
                    grossMargin: 105.57315281147139,
                    comprehensiveProfit: 105.57315281147139
                },

                {
                    footage: 25.0,
                    units: 121.26406122206913,
                    sales: 121.26406122206913,
                    grossMargin: 121.26406122206913,
                    comprehensiveProfit: 121.26406122206913
                }
            ]
        },
        {
            departmentID: 3328,
            benefitsForSizes: [
                {
                    footage: 35.0,
                    units: 84.55477350828399,
                    sales: 84.55477350828399,
                    grossMargin: 84.55477350828399,
                    comprehensiveProfit: 84.55477350828399
                },
                {
                    footage: 45.0,
                    units: 105.57315281147139,
                    sales: 105.57315281147139,
                    grossMargin: 105.57315281147139,
                    comprehensiveProfit: 105.57315281147139
                },
                {
                    footage: 55.0,
                    units: 121.26406122206913,
                    sales: 121.26406122206913,
                    grossMargin: 121.26406122206913,
                    comprehensiveProfit: 121.26406122206913
                }
            ]
        }
    ]
}