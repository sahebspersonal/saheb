import "./navbar.scss"
import image from './Walgreens-logo.png'

export const Navbar = () => {
  return (
    <div className='navbar'>
        <div className="wrapper">
           <div className="search">
           <span className="logo"><img width={190} height={100} margin-right={30} src={image} alt="Walgreens"/></span>
           </div>
           <div className="searchs">
           <p>SPACE BENEFIT CURVE USER INTERFACE</p>
           </div>
           <div className="items">
             <div className="item">
              
             </div>
               <div className="item">
               
                </div>

                <div className="item">
                
                </div>

                <div className="item">
                
                
                </div>

                <div className="item">
                
                </div>

                <div className="item">
               
                </div>

                <div className="item">
                
                </div>

           </div>
        </div>
    </div>
  )
}
