import React, { useState, useEffect } from "react";
// import { Sidebar } from "../../components/sidebar/Sidebar"
import { Navbar } from "../../components/navbar/Navbar"
import { Searchfield } from "../../components/searchfield/Searchfield"
import { Kpi } from "../../components/kpi/Kpi"
import { Chartss } from "../../components/chart/Chartss"
import { Halo } from "../../components/halo/Halo"
import axios from 'axios';
import "./home.scss"

const Home = () => {
  const [store, setStore] = useState('');
  const [selection, setSelection] = useState('');
  const [input, setInput] = useState({});
  const [departments, setDepartments] = useState({});

  const onSelectionChanged = index => {
    setSelection(index)
  }

  const onSelectionChanges = index => {
    setStore(index)
  }

  const onDataInput = (index) => {
    setInput(index);
  };

  const onDepartments = index => {
    setDepartments(index)
  }

  return (
    <div className='home'>

      <div className="homeContainer">
        <Navbar />

        <div className="widgetsfield">
          <Searchfield onSelectionChanged={onSelectionChanged} onSelectionChanges={onSelectionChanges} onDataInput={onDataInput} onDepartments={onDepartments}/>
        </div>

        <div className="charts">

          <Chartss selection={selection} storedata={store} inputdata={input}/>

        </div>

        <div className="widgetsfield">
          <Kpi selection={selection} storex={store} departments={departments} inputdatav={input}/>
        </div>

        <div className="widgetsfield">
          <Halo />
        </div>

      </div>
    </div>
  )
}

export default Home
