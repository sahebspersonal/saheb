import React, { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import PropTypes from 'prop-types';
import axios from 'axios';

export const Chartss = ({ selection, storedata, inputdata }) => {
  const [graphData, setGraphData] = useState([]);

  const inputDataArr = []
  for (const input in inputdata) {
    inputDataArr.push(inputdata[input]);
  }

  const sdata = {
    benefitModelID: 1,
    storeNbr: storedata,
    departmentList: [selection],
    benefitBlend: inputDataArr,
    useHalo: false
  }

  useEffect(() => {
    if (process.env.NODE_ENV !== 'test') {
      const url = 'https://ds-aks-pf.walgreens.com/mse/benefit-modeler/api/benefitCurve'
      axios.post(url, sdata)
        .then(res => {
          const benefits = res.data;
          setGraphData(benefits);
        })
        .catch(() => {
          return []
        })
    }
  }, [storedata, selection, inputdata]);

  const states = {
    series: [],
    options: {
      chart: {
        height: 550,
        type: 'scatter',
        zoom: {
          enabled: false,
          type: 'xy'
        }
      },
      xaxis: {
        tickAmount: 10,
        labels: {
          formatter: function (val) {
             parseFloat(val).toFixed(1);
          }
        }
      },
      yaxis: {
        tickAmount: 7,
        decimalsInFloat: 0
      }
    }
  };

  const seriesData = [];

  let item = [];
  if (selection) {
    item = graphData.find((i) => {
      return i.departmentID === selection;
    });
    seriesData.push(item);
  }

  if (seriesData[0] === undefined) {
    selection = '';
  } else {
    if (seriesData.length > 0) {
      for (const [key, value] of Object.entries(seriesData[0])) {
        if (key !== 'departmentID') {
          states.series.push({
            name: key,
            data: value
          });
        }
      }
    }
  }

  if (selection) {
    return (
      <div className="app">
        <div className="row">
          <div className="mixed-chart">
            <Chart
              options={states.options}
              series={states.series}
              type="scatter"
              height={500}
              width={1600}
            />
          </div>
        </div>
      </div>
    );
  } else {
    return (
      <div className="app">
        <div className="row">
          <div className="mixed-chart">
            <h2>Please select department</h2>
          </div>
        </div>
      </div>
    );
  }
};

Chartss.propTypes = {
  selection: PropTypes.any,
  storedata: PropTypes.any,
  inputdata: PropTypes.any
}
