import React from 'react';
import PropTypes from 'prop-types';
import Sidebar from 'react-sidebar';

const styles = {
  divider: {
    margin: '8px 0',
    height: 1,
    backgroundColor: '#757575'
  },
  root: {
    fontWeight: 300,
    width: 256,
    height: '100%'
  },
  header: {
    backgroundColor: '#03a9f4',
    color: 'white',
    padding: '10px 12px',
    fontSize: '1.5em'
  }
};

const SidebarLayout = ({ title, children, sidebarContent, sidebarProps }) => {
  const sidebar = (
    <div style={styles.root}>
      <div style={styles.header}>{title}</div>
      {sidebarContent}
    </div>
  );
  const sProps = { sidebar, ...sidebarProps };
  return <Sidebar {...sProps}>{children}</Sidebar>;
};

SidebarLayout.propTypes = {
  title: PropTypes.string,
  sidebarProps: PropTypes.any,
  sidebarContent: PropTypes.node,
  children: PropTypes.node.isRequired
};

export default SidebarLayout;
