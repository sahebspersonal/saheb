import React from 'react';
import { cleanup, render } from '@testing-library/react';
import ToastBox from '../../core/toast-box/toast-box';

describe('ToastBox', () => {
  const ToastHeader = (
    <>
      <strong className="me-auto">TOAST HEADER</strong>
      <small>11 mins ago</small>
    </>
  );
  beforeEach(() => {
    cleanup();
  });

  it('should able to render app', () => {
    const app = render(
      <ToastBox
        header={ToastHeader}
        body={'Hello, world! This is a toast message'}
      />
    );
    expect(app).toBeTruthy();
  });
});
