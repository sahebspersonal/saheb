import axios from 'axios';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { Button } from '@mui/material';
import React, { useState, useEffect } from 'react';
import './searchfield.scss';

export const Searchfield = ({ onSelectionChanged, onSelectionChanges, onDataInput, onDepartments, onChecked }) => {
  const [store, setStore] = useState('');
  const [checked, setChecked] = useState(false)
  const [department, setDepartment] = useState('');
  const [datan, setDatan] = useState([]);
  const [input, setInput] = useState({
    units: '',
    sales: '',
    margin: '',
    profit: ''
  });
  const [sum, setSum] = React.useState(undefined);

  const handleCheck = (event) => {
    setChecked(event.currentTarget.checked);
};

  const handleInput = function (e) {
    setInput({
      ...input,
      [e.target.name]: e.target.value
    });
  };
  useEffect(() => {
    const sdata = {
      benefitModelID: 1,
      storeNbr: "All",
      departmentList: ["All"],
      benefitBlend: ["25", "25", "25", "25"]
    }
    const url = 'https://ds-aks-pf.walgreens.com/mse/benefit-modeler/api/currentBenefits'
    //         setDatan(doPostRequest(url,sdata))
    axios.post(url, sdata)
      .then(res => {
        const benefits = res.data;
        setDatan(benefits);
      })
      .catch(() => {
        return []
      })
  }, []);

  useEffect(() => {
    setSum(
      parseInt(input.units) +
      parseInt(input.sales) +
      parseInt(input.margin) +
      parseInt(input.profit)
    );
  }, [input]);

  const ser = datan.map((item) => {
    return item.storeNbr;
  });

  const ndata = [];

  if (store) {
    const vall = datan.find((vv) => vv.storeNbr === store);
    ndata.push(vall);
  }
  const serz = ndata.map((item) => {
    return item.BenefitListForDepartments;
  });
  const mergex3 = serz.flat(1);

  const ser1 = mergex3.length > 1
  ? mergex3.map((item) => {
    return item.departmentID;
  })
  : [];

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  return (
    <div className="searchfield">
      <form
        id="registrationForm"
        action="/"
        method="POST"
        onSubmit={handleSubmit}
      >
        <div className="wrapper">
          <Autocomplete
            disablePortal
            className=""
            id="combo-box-demo"
            options={ser}
            value={store}
            onChange={(_event, newTeam) => {
              setStore(newTeam);
            }}
            sx={{ width: 200 }}
            renderInput={(params) => <TextField {...params} label="Store" />}
          />

          <Autocomplete
            disablePortal
            className=""
            id="combo-box-demo"
            options={ser1}
            value={department}
            onChange={(_event, newTeam) => {
              setDepartment(newTeam);
            }}
            sx={{ width: 200 }}
            renderInput={(params) => (
              <TextField {...params} label="Department" />
            )}
          />

          <Box
            component="form"
            sx={{
              '& > :not(style)': { m: 1, width: '13ch' }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="units"
              value={input.units}
              id="outlined-basic"
              label="Units"
              variant="outlined"
            />
          </Box>

          <Box
            component="form"
            sx={{
              '& > :not(style)': { m: 1, width: '13ch' }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="sales"
              value={input.sales}
              id="outlined-basic"
              label="Sales"
              variant="outlined"
            />
          </Box>

          <Box
            component="form"
            sx={{
              '& > :not(style)': { m: 1, width: '13ch' }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="margin"
              value={input.margin}
              id="outlined-basic"
              label="Margin"
              variant="outlined"
            />
          </Box>

          <Box
            component="form"
            sx={{
              '& > :not(style)': { m: 1, width: '13ch' }
            }}
            noValidate
            autoComplete="off"
          >
            <TextField
              onKeyPress={(event) => {
                if (!/[0-9]/.test(event.key)) {
                  event.preventDefault();
                }
              }}
              onChange={handleInput}
              name="profit"
              value={input.profit}
              id="outlined-basic"
              label="Profit"
              variant="outlined"
            />
          </Box>
          <Box>
          <FormGroup className="fg">
                    <FormControlLabel control={<Checkbox checked={checked} onChange={handleCheck} />} label="Halo" />
                </FormGroup>
                </Box>
          <Button
            variant="contained"
            className="button"
            disabled={sum !== 100}
            onClick={() =>
              onSelectionChanged(department, onSelectionChanges(store), onDataInput(input), onDepartments(ser1), onChecked(checked))
            }
          >
            Go
          </Button>
        </div>
      </form>
    </div>
  );
};

Searchfield.propTypes = {
  onSelectionChanged: PropTypes.any,
  onSelectionChanges: PropTypes.any,
  onDataInput: PropTypes.any,
  onDepartments: PropTypes.any,
  onChecked: PropTypes.any
};
