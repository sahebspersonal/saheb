import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('Stand in Test.  It needs to be replaced', () => {
  render(<App />);
  const linkElement = screen.getByText(/SPACE BENEFIT CURVE USER INTERFACE/i);
  expect(linkElement).toBeInTheDocument();
});
