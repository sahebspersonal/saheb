import React, { Fragment, useEffect, useMemo, useState } from 'react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import PropTypes from 'prop-types';
import { Button } from 'react-bootstrap';
import { AgGridReact } from 'ag-grid-react';

const UseGridTable = ({ columns, data, onAddRow }) => {
  // style for the button container
  const buttonContainerStyle = useMemo(() => ({
    width: 'calc(100% - 20px)',
    textAlign: 'right',
    padding: '10px'
  }), []);

  // columns updated using useMemo
  const columnDefs = useMemo(() => columns, [columns]);

  // default features of table initiated
  const columnFeatureDefs = useMemo(
    () => ({
      sortable: true,
      flex: 1,
      resizable: true
    }),
    []
  );

  // update data when rows updated
  const [rowData, setRowData] = useState();
  useEffect(() => {
    setRowData(data);
  }, [data]);

  return (
    <Fragment>
      {onAddRow && (
        <div style={buttonContainerStyle}>
          <Button variant="outline-primary" onClick={onAddRow}>
            Add Row
          </Button>
        </div>
      )}
      <AgGridReact
        className="ag-theme-alpine"
        columnDefs={columnDefs}
        defaultColDef={columnFeatureDefs}
        rowData={rowData}
      />
    </Fragment>
  );
};

UseGridTable.propTypes = {
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      field: PropTypes.string,
      editable: PropTypes.bool
    })
  ),
  data: PropTypes.any,
  onAddRow: PropTypes.func
};

export default UseGridTable;
