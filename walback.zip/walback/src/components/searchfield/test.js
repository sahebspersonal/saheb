const  axios =require("axios");
//import axios from 'axios'

const dsProdfix=async()=>{
    try{
        const result =await axios({
            method: 'post',
            url: 'https://ds-prodfix-interface.walgreens.com/mse/benefit-modeler/api/currentBenefits',
            data: {
                     "benefitModelID": 1,
                     "storeNbr": "All",
                     "departmentList": ["All"]
    
            },
            headers: {
               'Ocp-Apim-Subscription-Key': '4a109346edf04a06babeba3f9d669227',
               'Ocp-Apim-Trace': true,
               'Content-Type': 'application/json'
            }
        })
        console.log('result ',result)
    } catch (err){
         console.log(err)
    }
    
}
dsProdfix();