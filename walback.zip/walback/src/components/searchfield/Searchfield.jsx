import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import TextField from '@mui/material/TextField';
import { Button } from "@mui/material";
import React, { useState, useEffect } from "react";
import "./searchfield.scss";
import { data } from "./data"
import axios from 'axios'

export const Searchfield = ({ onSelectionChanged }) => {
    const [store, setStore] = useState('');
    const [department, setDepartment] = useState('');
    const [disable, setDisable] = useState(false);
    const [input, setInput] = useState({
        units: "",
        sales: "",
        margin: "",
        profit: ""
    });
    const [sum, setSum] = React.useState(undefined)
    const handleInput = function (e) {
        setInput({
            ...input,
            [e.target.name]: e.target.value
        });
    };
    useEffect(() => {
        setSum(parseInt(input.units) + parseInt(input.sales) + parseInt(input.margin) + parseInt(input.profit))

    }, [input])

    //console.log('sum.......',sum)

    var ndata = [];
    if (!!store) {
        var vall = data.find(vv => vv.storeNbr == store);

        ndata.push(vall);
    }

    const buildDepart = (ndata) => {

        if (ndata.length > 0) {
            return ndata[0].BenefitListForDepartments

        } else {
            return [];
        }
    }


    //const availableStore = data.stores.find((c) => c.id === store);

    const handleChange = (event) => {
        setStore(event.target.value);

    };

    const handleChangeDepartment = (event) => {
        setDepartment(event.target.value);

    }

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    return (
        <div className="searchfield">
            <form
                id="registrationForm"
                action="/"
                method="POST"
                onSubmit={handleSubmit}
            >
                <div className="wrapper">

                    <Box sx={{ minWidth: 120 }} className="fg">
                        <FormControl fullWidth >
                            <InputLabel id="demo-simple-select-label">Store</InputLabel>
                            <Select
                                name="fName"
                                id="fName"
                                className="autocomplete"
                                labelId="demo-simple-select-label"
                                //id="demo-simple-select"
                                value={store}
                                label="Store"
                                onChange={handleChange}
                            >
                                <MenuItem value={0}>Select</MenuItem>
                                {

                                    data.map((itemt, key) => {
                                        return (
                                            <MenuItem key={key} value={itemt.storeNbr}>{itemt.storeNbr}</MenuItem>
                                        )
                                    })

                                }

                            </Select>
                        </FormControl>
                    </Box>
                    <Box sx={{ minWidth: 120 }} className="fg">
                        <FormControl fullWidth >
                            <InputLabel id="demo-simple-select-label">Department</InputLabel>
                            <Select
                                className="autocomplete"
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={department}
                                label="Department"
                                onChange={handleChangeDepartment}
                            >
                                <MenuItem value={0}>Select</MenuItem>
                                {

                                    buildDepart(ndata).map((itemts, keys) => {
                                        return (
                                            <MenuItem key={keys} value={itemts.departmentID}>{itemts.departmentID}</MenuItem>
                                        )
                                    })

                                }

                            </Select>
                        </FormControl>
                    </Box>

                    <Box
                        component="form"
                        sx={{
                            '& > :not(style)': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        <TextField onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }} onChange={handleInput} name="units" value={input.units} id="outlined-basic" label="Units" variant="outlined" />
                    </Box>

                    <Box
                        component="form"
                        sx={{
                            '& > :not(style)': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        <TextField onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }} onChange={handleInput} name="sales" value={input.sales} id="outlined-basic" label="Sales" variant="outlined" />
                    </Box>

                    <Box
                        component="form"
                        sx={{
                            '& > :not(style)': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        <TextField onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }} onChange={handleInput} name="margin" value={input.margin} id="outlined-basic" label="Margin" variant="outlined" />
                    </Box>

                    <Box
                        component="form"
                        sx={{
                            '& > :not(style)': { m: 1, width: '25ch' },
                        }}
                        noValidate
                        autoComplete="off"
                    >
                        <TextField onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }} onChange={handleInput} name="profit" value={input.profit} id="outlined-basic" label="Profit" variant="outlined" />
                    </Box>

                    <Button variant="contained" className="button" disabled={sum !== 100} onClick={() => onSelectionChanged(department)}>Go</Button>


                </div>
            </form>
        </div>
    )
}
