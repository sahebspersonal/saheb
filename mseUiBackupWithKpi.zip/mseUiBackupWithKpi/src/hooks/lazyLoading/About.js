import React, { Fragment } from "react";

const About = () => {
return (
    <Fragment>
        <h1>About Us Page being constructed. Please try after some days.</h1>
    </Fragment>
)
}

export default About
