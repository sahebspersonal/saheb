import Box from '@mui/material/Box';
import Autocomplete from "@mui/material/Autocomplete";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import React, { useState, useEffect } from "react";
import "./kpi.scss";
import Chart from "react-apexcharts";
import PropTypes from 'prop-types';
import { Button } from '@mui/material';
import TextField from '@mui/material/TextField';
import { bdata } from "./bdata"
import { mdata } from "./mdata"
import axios from 'axios';

export const Kpi = ({ selection, storex, departments }) => {
    // const [store, setStore] = useState(0);
    const [department1, setDepartment1] = useState('');
    const [department2, setDepartment2] = useState('');
    const [department3, setDepartment3] = useState('');
    const [department4, setDepartment4] = useState('');
    const [footage, setFootage] = useState(0)
    const [plot, setPlot] = useState(false)
    const [plot2, setPlot2] = useState(false)
    const [plot3, setPlot3] = useState(false)
    const [plot4, setPlot4] = useState(false)
    const [plotData1, setPlotData1] = useState('')
    const [plotData2, setPlotData2] = useState('')
    const [plotData3, setPlotData3] = useState('')
    const [plotData4, setPlotData4] = useState('')
    const [graphData1, setGraphData1] = useState({});
    const [graphData2, setGraphData2] = useState({});
    const [graphData3, setGraphData3] = useState({});
    const [graphData4, setGraphData4] = useState({});
    const [inputss, setInputss] = useState({
        footage1: "",
        footage2: "",
        footage3: ""
    });

    const handleInput = function (e) {
        setInputss({
            ...inputss,
            [e.target.name]: e.target.value
        });
    };
    
    const footageChange = (event) => {
        setFootage(event.target.value);
    }

    const inputDataArr = []
    for (let input in inputss) {
      inputDataArr.push(inputss[input]);
    }

    function apiCall(index, plotNumber){
        console.log('Function call - True')
        const sdata = {
            benefitModelID: 1,
            storeNbr: storex,
            departmentListAndSizes: [
                {
                    departmentID: index,
                    footage: inputDataArr
                }
            ],
            useHalo: false
        }
    
            const url = 'https://ds-aks-qa.walgreens.com/mse/benefit-modeler/api/modeledBenefits'
             axios.post(url, sdata)
              .then(res => {
                const benefits = res.data;
                //setGraphData(benefits);
                console.log(benefits)
                console.log('plotNumber',plotNumber)
                //return benefits
                if(plotNumber ==="plot1"){
                    //setGraphData1(benefits)
                    setPlot(true)
                    setPlotData1(index)
                   doOperationBeforeGraph(benefits,plotNumber,index)
                }else if(plotNumber ==="plot2"){
                    //setGraphData2(benefits)
                    setPlot2(true)
                    setPlotData2(index)
                   doOperationBeforeGraph(benefits,plotNumber,index)
                }else if(plotNumber ==="plot3"){
                    //setGraphData3(benefits)
                    setPlot3(true)
                    setPlotData3(index)
                    doOperationBeforeGraph(benefits,plotNumber,index)
                }else if(plotNumber ==="plot4"){
                     //setGraphData4(benefits)
                     setPlot4(true)
                     setPlotData4(index)
                     doOperationBeforeGraph(benefits,plotNumber,index)
                }
            })
    }
    
    const ser1 = departments.length>1? departments:[];
    
 function doOperationBeforeGraph(apiGraphData, mapNo, plot){
    console.log('apiGraphData',apiGraphData)
    console.log('mapNo',mapNo)
    console.log('plot',plot)
       const graphDataArrApi =apiGraphData!==null && apiGraphData.departmentListAndSizes!==null? apiGraphData.departmentListAndSizes:[];
       drawMap(graphDataArrApi, mapNo, plot)
    }
    let newval1, newval2, newval3, newval4;
    function drawMap(mapData, mapNo, plot){
        console.log('EE',mapData)
            const plotdata11 = mapData.length>0?mapData.find((item) => {
                return item.departmentID === plot
            }):[];

            console.log('FF',plotdata11)

            if (typeof (plotdata11) !== 'undefined' && plotdata11 != null) {
                const plotdatas11 = plotdata11.benefitsForSizes
                const tr1 = plotdatas11.reduce((r, o) => {
                    Object.entries(o).forEach(([k, v]) => {
                        r[k] = r[k] || []
                        if (!r[k].includes(v)) r[k].push(v)
                    });
                    return r;
                },
                    Object.create(null));
    
                const obj = JSON.parse(JSON.stringify(tr1)); const ser = []; ser.push(obj);
                if (ser.length > 0) {
                    for (const [key, value] of Object.entries(ser[0])) {
                        ser.push({
    
                            name: key.charAt(0).toUpperCase() + key.slice(1),
                            data: value
                        })
                    }
                }
                if(mapNo ==="plot1"){
                    newval1 = ser.slice(1);
                    setGraphData1(newval1)
                }else if(mapNo ==="plot2"){
                    newval2 = ser.slice(1);
                    setGraphData2(newval2)
                }else if(mapNo ==="plot3"){
                    newval3 = ser.slice(1);
                    setGraphData3(newval3)
                }else if(mapNo ==="plot4"){
                    newval4 = ser.slice(1);
                    setGraphData4(newval4)
                }

            
        }

       
    }
    console.log('newval2',graphData2)

    const state = {
        series: graphData1,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData1}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state2 = {
        series: graphData2,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData2}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state3 = {
        series: graphData3,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData3}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const state4 = {
        series: graphData4,
        options: {
            chart: { height: 350, type: 'line', zoom: { enabled: false } },
            dataLabels: { enabled: false },
            stroke: { width: [5, 5, 5, 5, 5], curve: 'straight', dashArray: [0, 0, 0, 0, 0] },
            title: { text: `Department - ${plotData4}`, align: 'left' },
            legend: {
                tooltipHoverFormatter: function (val, opts) {
                    return `${val} - ${opts.w.globals.series[opts.seriesIndex][opts.dataPointIndex]}`
                }
            },
            markers: { size: 0, hover: { sizeOffset: 6 } },
            xaxis: { categories: ['1', '2', '3'] },
            yaxis: { decimalsInFloat: 0 },
            grid: { borderColor: '#f1f1f1' }
        }
    };

    const seriesDataz = [];

    let itemsz = [];
    if (selection) {
        // if (selection != null) {
        itemsz = bdata.find((item) => {
            if (item.departmentID === selection) {
                return true;
            } else {
                return false;
            }
        });
    }

    if (typeof (itemsz) !== 'undefined' && itemsz != null) {
        seriesDataz.push(itemsz)
    }

    const iitem = seriesDataz.map((item) => {
        return item.STORE_TREND
    });

    function getMax (a) {
        return Math.max(...a.map(e => Array.isArray(e) ? getMax(e) : e));
    }

    const maxv = getMax(iitem)

    const buildOptions = () => {
        const arr = [];

        for (let i = 1; i <= maxv; i++) {
            arr.push(<MenuItem key={i} value={i}>{i}</MenuItem>)
        }

        return arr;
    }

    return (
        <div className="container">
            <div className="wrapper">
                <Box sx={{ minWidth: 120 }} className="fg">
                    <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label">Footage</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={footage}
                            label="Footage"
                            onChange={footageChange}
                        >
                            <MenuItem value="0">Select</MenuItem>
                            {
                                buildOptions()
                            }
                        </Select>
                    </FormControl>
                </Box>

                <Box
                    className="fg"
                    component="form"
                    sx={{ minWidth: 120 }}
                    noValidate
                    autoComplete="off"
                >
                    <TextField onKeyPress={(event) => {
                        if (!/[0-9]/.test(event.key)) {
                            event.preventDefault();
                        }
                    }} onChange={handleInput} name="footage1" value={inputss.footage1} id="outlined-basic" label="Footage 1" variant="outlined" />
                </Box>

                <Box
                    className="fg"
                    component="form"
                    sx={{ minWidth: 120 }}
                    noValidate
                    autoComplete="off"
                >
                    <TextField onKeyPress={(event) => {
                        if (!/[0-9]/.test(event.key)) {
                            event.preventDefault();
                        }
                    }} onChange={handleInput} name="footage2" value={inputss.footage2} id="outlined-basic" label="Footage 2" variant="outlined" />
                </Box>

                <Box
                    className="fg"
                    component="form"
                    sx={{ minWidth: 120 }}
                    noValidate
                    autoComplete="off"
                >
                    <TextField onKeyPress={(event) => {
                        if (!/[0-9]/.test(event.key)) {
                            event.preventDefault();
                        }
                    }} onChange={handleInput} name="footage3" value={inputss.footage3} id="outlined-basic" label="Footage 3" variant="outlined" />
                </Box>

            </div>
            <div className="halo">

                <div className="dropdown">
                    <Autocomplete
                        disablePortal
                        className="dd"
                        id="combo-box-demo"
                        options={ser1}
                        value={department1}
                        //getOptionLabel={(option) => typeof option === 'string' || option instanceof String ? option : ""}
                        onChange={(_event, newTeam) => {
                            setDepartment1(newTeam);
                            if (newTeam === '0') {
                                setPlot(false)
                            } else {
                                apiCall(newTeam, 'plot1')
                                //setPlot(true)
                                //setPlotData1(newTeam)
                                
                            }
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => <TextField {...params} label="Department" />}
                    />

                    <Autocomplete
                        disablePortal
                        className="dd"
                        id="combo-box-demo"
                        options={ser1}
                        value={department2}
                        //getOptionLabel={(ooption) => typeof ooption === 'string' || ooption instanceof String ? ooption : ""}
                        onChange={(_event, newTeam) => {
                            setDepartment2(newTeam);
                            if (newTeam === '0') {
                                setPlot2(false)
                            } else {
                                apiCall(newTeam, 'plot2')
                                // setPlot2(true)
                                // setPlotData2(newTeam)
                            }
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => <TextField {...params} label="Department" />}
                    />

                    <Autocomplete
                        disablePortal
                        className="dd"
                        id="combo-box-demo"
                        options={ser1}
                        value={department3}
                        onChange={(_event, newTeam) => {
                            setDepartment3(newTeam);
                            if (newTeam === '0') {
                                setPlot3(false)
                            } else {
                                apiCall(newTeam, 'plot3')
                                // setPlot3(true)
                                // setPlotData3(newTeam)
                            }
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => <TextField {...params} label="Department" />}
                    />

                    <Autocomplete
                        disablePortal
                        className="dd"
                        id="combo-box-demo"
                        options={ser1}
                        value={department4}
                        onChange={(_event, newTeam) => {
                            setDepartment4(newTeam);
                            if (newTeam === '0') {
                                setPlot4(false)
                            } else {
                                apiCall(newTeam, 'plot4')
                                // setPlot4(true)
                                // setPlotData4(newTeam)
                            }
                        }}
                        sx={{ width: 300 }}
                        renderInput={(params) => <TextField {...params} label="Department" />}
                    />
                </div>
            </div>
            <div className="containers">
                <div>
                    {
                        graphData1?.length > 0
? (
                            <div>
                                {
                                    plot && (
                                        <div id="chart">
                                            <Chart
                                                options={state.options}
                                                series={state.series}
                                                type="line"
                                                width="450"
                                            />
                                        </div>
                                    )

                                }
                            </div>
                        )
: (
                            <p className='nodata' />
                        )

                    }
                </div>
                <div>
                    {
                        graphData2?.length > 0
? (
                            <div>
                                {
                                    plot2 && (
                                        <div id="chart">
                                            <Chart
                                                options={state2.options}
                                                series={state2.series}
                                                type="line"
                                                width="450"
                                            />
                                        </div>
                                    )

                                }
                            </div>
                        )
: (
                            <p className='nodata' />
                        )

                    }
                </div>
                <div>
                    {
                        graphData3?.length > 0
? (
                            <div>
                                {
                                    plot3 && (
                                        <div id="chart">
                                            <Chart
                                                options={state3.options}
                                                series={state3.series}
                                                type="line"
                                                width="450"
                                            />
                                        </div>
                                    )

                                }
                            </div>
                        )
: (
                            <p className='nodata' />
                        )

                    }
                </div>
                <div>
                    {
                        graphData4?.length > 0
? (
                            <div>
                                {
                                    plot4 && (
                                        <div id="chart">
                                            <Chart
                                                options={state4.options}
                                                series={state4.series}
                                                type="line"
                                                width="450"
                                            />
                                        </div>
                                    )

                                }
                            </div>
                        )
: (
                            <p className='nodata' />
                        )

                    }
                </div>

            </div>
        </div>
    )
}

Kpi.propTypes = {
    selection: PropTypes.any,
    storex: PropTypes.any,
    departments: PropTypes.any
}
