import React, { Fragment } from "react";

const Home = () => {
return (
    <Fragment>
        <h1 clasName="App-header">Welcome to Walgreens</h1>
        <h4>Page being constructed. Please try after some days.</h4>
    </Fragment>
)
}

export default Home
