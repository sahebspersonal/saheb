import React from 'react';
import PropTypes from 'prop-types';
import Toast from 'react-bootstrap/Toast';

const ToastBox = ({ header, body }) => {
  return (
    <Toast>
      <Toast.Header>{header}</Toast.Header>
      <Toast.Body>{body}</Toast.Body>
    </Toast>
  );
};

ToastBox.propTypes = {
  header: PropTypes.string,
  body: PropTypes.string
};

export default ToastBox;
