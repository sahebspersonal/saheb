import React from 'react';
import { cleanup, render } from '@testing-library/react';
import Button from '../../core/button/button';

describe('Button', () => {
  beforeEach(() => {
    cleanup();
  });

  it('should able to render Button', () => {
    const app = render(
      <Button varient="primary" size="sm">
        Primary Button
      </Button>
    );
    expect(app).toBeTruthy();
    expect(app.queryByText(/Primary Button/i)).toBeTruthy();
  });
});
