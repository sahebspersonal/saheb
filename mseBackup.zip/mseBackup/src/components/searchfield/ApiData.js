import axios from 'axios';

export default function getAPI (v, callbackFn){
  axios.post(v)
    .then((res)=>{
      dataJson =  res.data
      console.log(dataJson) // this would print responsecallbackFn(dataJson)
    })
}

export const ApiData = () => {
        const data = {
              benefitModelID: 1,
              storeNbr: 3571,
              departmentList: ["3328", "3410"],
              benefitBlend: [1.0, 2.0, 3.0, 4.0],
              useHalo: false
            }
            const url = 'https://ds-aks-qa.walgreens.com/mse/benefit-modeler/api/currentBenefits'
            //console.log(url)
        axios.post(url, data)
              .then(res => {
                return res.data;
              })
        .catch((error) => {
            if( error.response ){
                console.log(error.response.data); // => the response payload 
            }
        });

  } 