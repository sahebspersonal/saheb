
import axios from "axios";

export default axios.create({
  baseURL: "https://ds-aks-qa.walgreens.com/mse/benefit-modeler/api",
  headers: {
    "Content-type": "application/json"
  }
});