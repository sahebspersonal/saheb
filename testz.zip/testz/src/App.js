
import BenefitList from './BenefitList';
import './App.css';
import BenefitCurve from './BenefitCurve';

function App() {
  return (
    <div className="App">
    <BenefitCurve/>
    </div>
  );
}

export default App;
