
import React from 'react';
import axios from 'axios';
export default class BenefitList extends React.Component {
  state = {
    persons: [],
    benefits: []
  }
  componentDidMount() {
    const data = {
      "benefitModelID": 1,
      "storeNbr": 3571,
      "departmentList": ["3328", "3410"],
      "benefitBlend": [1.0, 2.0, 3.0, 4.0],
      "useHalo": false
    }
    const url = 'https://ds-aks-qa.walgreens.com/mse/benefit-modeler/api/benefitCurve'
    console.log(url)
    axios.post(url, data)
      .then(res => {
        const benefits = res.data;
        console.log(benefits)
        this.setState({ benefits });
      })
  }
render() {
    return (
      <ul>
        {
          this.state.benefits
            .map(i =>
              <li key={i.departmentID}>{i.departmentID}
                <ul>
                  <li><label>CHAIN: </label>{i.CHAIN}</li>
                  <li><label>CLUSTER: </label>{i.CLUSTER}</li>
                  <li><label>CLUSTER_TREND: </label>{i.CLUSTER_TREND}</li>
                  <li><label>STORE: </label>{i.STORE}</li>
                  <li><label>STORE_TREND: </label>{i.STORE_TREND}</li>
                </ul>
              </li>
            )
        }
      </ul>
    )
  }
}

