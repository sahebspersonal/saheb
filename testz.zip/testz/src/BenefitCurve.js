import React, { useRef, useState } from "react";
import "./App.css";

import apiClient from "./http-common";

function BenefitCurve() {
//   const post_title = useRef(null);
//   const post_description = useRef(null);

  const [postResult, setPostResult] = useState('');

  const fortmatResponse = (res) => {
    return JSON.stringify(res, null, 2);
  };

   function postData() {
        const data = {
              "benefitModelID": 1,
              "storeNbr": 3571,
              "departmentList": ["3328", "3410"],
              "benefitBlend": [1.0, 2.0, 3.0, 4.0],
              "useHalo": false
            }
            //const url = 'https://ds-aks-qa.walgreens.com/mse/benefit-modeler/api/benefitCurve'
            //console.log(url)
        apiClient.post('/benefitCurve', data)
              .then(res => {
                const benefits = res.data;
                console.log(benefits)
                this.setState({ benefits });
              })
        .catch((error) => {
            if( error.response ){
                console.log(error.response.data); // => the response payload 
            }
        });

  } 


const clearPostOutput = () => {
  setPostResult(null);
};


return (
    <div id="app" className="container">
      <div className="card">
        <div className="card-header">React Axios POST - BezKoder.com</div>
        <div className="card-body">
            {/*
          <div className="form-group">
            <input type="text" className="form-control" ref={post_title} placeholder="Title" />
          </div>
          <div className="form-group">
            <input type="text" className="form-control" ref={post_description} placeholder="Description" />
          </div>*/}
          <button className="btn btn-sm btn-primary" onClick={postData}>Post Data</button>
          <button className="btn btn-sm btn-warning ml-2" onClick={clearPostOutput}>Clear</button>

          { postResult && <div className="alert alert-secondary mt-2" role="alert"><pre>{postResult}</pre></div> }
        </div>
      </div>
    </div>
  );
}

export default BenefitCurve;