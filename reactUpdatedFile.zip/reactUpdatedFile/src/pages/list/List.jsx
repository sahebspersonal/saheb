import React from 'react'

function List() {
  return (
    <div>List</div>
  )
}

export default List