import React from 'react';

const Blended = () => {
  return <div>Blended</div>;
};

export default Blended;
