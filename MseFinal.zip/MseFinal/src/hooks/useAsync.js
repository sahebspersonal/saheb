import { useState, useEffect, useCallback } from "react";

const useAsync = (asyncFunction, immediate = false) => {
  const [status, setStatus] = useState("idle");
  const [value, setValue] = useState(null);
  const [error, setError] = useState(null);

  const executeAsync = useCallback(() => {
    setStatus("pending");
    setValue(null);
    setError(null);
    return asyncFunction()
      .then((response) => {
        setValue(response);
        setStatus("success");
      })
      .catch((returnnedError) => {
        setError(returnnedError);
        setStatus("error");
      });
  }, [asyncFunction]);

  useEffect(() => {
    if (immediate) {
        executeAsync();
    }
  }, [executeAsync, immediate]);
  return { executeAsync, status, value, error };
};

export default useAsync

// A hook for simplifying managment of Async functions
// the hook takes two parameters
//  1st the aysnc function you want to use
//  2nd a boolean. true if you want it to execute the function immediatly / false if you want to invoke it
//
// the hook returns
//  executeAsync : a callback function to run your Async functions
//  status : gives the current status of the Async function [idle, pending, success, error]
//  value : the response from the Async function passed to the hook.  it will be null unless a succesful respone is recieved
//  error : any errors returned by the Async function passed to the hook
//
//
// example:
// const { executeAsync, status, value, error } = useAsync(myFunction, false);
//
//    return (
//    <div>
//    {status === "idle" && <div>Start your journey by clicking a button</div>}
//    {status === "success" && <div>{value}</div>}
//    {status === "error" && <div>{error}</div>}
//    <button onClick={execute} disabled={status === "pending"}>
//      {status !== "pending" ? "Click me" : "Loading..."}
//    </button>
// </div>
//  );
